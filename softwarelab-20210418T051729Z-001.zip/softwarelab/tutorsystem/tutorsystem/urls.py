
from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home),
    path('login/',views.login),
    path('registration/',views.registration),
    path('subjects/', views.showSubject),



    path('students/', views.showStudent),
    path('teachers/', views.showTeacher),
    path('reviews/', views.showReview),







]


