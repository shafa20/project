from django.http import HttpResponse
from django.shortcuts import render
from tutors .models  import Subject
from tutors .models import Student
from tutors .models import Teacher
from tutors .models import Review








def home(request):
   return render(request, 'home.html')
def login(request):
   return render(request, 'login.html')
def registration(request):
   return render(request, 'registration.html')





def showSubject(request):
   allSubjects = Subject.objects.all()
   print(allSubjects)
   context = {"allSubjects": allSubjects}
   return render(request, 'subjects.html',context)


def showStudent(request):
   allStudents = Student.objects.all()
   print(allStudents)
   context = {"allStudents": allStudents}
   return render(request, 'students.html',context)

def showTeacher(request):
   allTeachers = Teacher.objects.all()
   print(allTeachers)
   context = {"allTeachers": allTeachers}
   return render(request, 'teachers.html',context)

def showReview(request):
      allReviews = Review.objects.all()
      print(allReviews)
      context = {"allReviews": allReviews}
      return render(request, 'reviews.html',context)








