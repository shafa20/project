from django.db import models

# Create your models here.
class Subject(models.Model):

    subject_ID= models.IntegerField(default=0)
    subject_name = models.CharField(max_length=100, default="")
    def  __str__(self):
        return self.subject_name




class Student (models.Model):

    name = models.CharField(max_length=100, default="")
    Class = models.CharField(max_length=100, default="")
    gmail = models.CharField(max_length=100, default="")
    phone = models.CharField(max_length=100, default="")
    address = models.CharField(max_length=100, default="")

    def __str__(self):
        return self.name


class Teacher(models.Model):
    subject = models.ForeignKey(Subject,on_delete=models.CASCADE)
    teacher_name = models.CharField(max_length=100, default="")
    gmail = models.CharField(max_length=100, default="")
    phone = models.CharField(max_length=100, default="")
    education_qualification = models.CharField(max_length=100, default="")
    address = models.CharField(max_length=100, default="")
    course_fee = models.CharField(max_length=100, default="")
    def  __str__(self):
        return self.teacher_name




class Review(models.Model):

    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    review_ID = models.IntegerField(default=0)
    comment = models.CharField(max_length=100, default="")

    def  __str__(self):
        return self.comment


