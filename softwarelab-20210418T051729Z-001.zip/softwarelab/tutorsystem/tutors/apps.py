from django.apps import AppConfig


class TutorsConfig(AppConfig):
    name = 'tutors'
